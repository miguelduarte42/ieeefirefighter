package lejos.pc.tools;

import lejos.pc.comm.NXTCommLogListener;

/**
 * 
 * @author scholz
 * listener for log events that arise in pctools
 */

public interface ToolsLogListener extends NXTCommLogListener {
	
}
