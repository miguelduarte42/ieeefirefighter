
package lejos.pc.tools;

/**
 *
 * @author andy
 */
public interface ConsoleDebug {
    public void exception(int classNo, String msg, int[] stackTrace);
}
