package javax.microedition.io;

import java.io.IOException;

public interface Connection {
	public void close() throws IOException;
}
