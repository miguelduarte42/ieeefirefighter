package lejos.robotics.kinematics;

public class PointUnreachableException extends Exception {
	// Inherits everything from Exception
}
