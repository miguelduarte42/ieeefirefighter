package java.lang;

public class StackOverflowError extends Error
{
	public StackOverflowError()
	{
		super();
	}

	public StackOverflowError(String message)
	{
		super(message);
	}	
}
