

package java.lang;

public class ArrayStoreException extends RuntimeException
{
}
