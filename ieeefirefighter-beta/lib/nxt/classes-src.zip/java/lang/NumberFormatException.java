package java.lang;

public class NumberFormatException extends IllegalArgumentException
{
	public NumberFormatException()
	{
		super();
	}

	public NumberFormatException(String s)
	{
		super(s);
	}
}
