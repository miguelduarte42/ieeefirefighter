package java.util;

/**
 * Every event in Java implement this interface
 * 
 * @author Juan Antonio Brenha Moral
 */
public interface EventListener {
	//Empty
}
